package com.visualpathit.account.controllerTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SampleTest {
	@Test
	public void SampleTestHappyFlow(){
		assertEquals("Hello".length(), 5);
	}

}
